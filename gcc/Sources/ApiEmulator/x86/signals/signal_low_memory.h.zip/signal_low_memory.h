#ifndef SIGNAL_H
#define SIGNAL_H


#include <functional>
#include <list>


namespace signal_slot {


class simple_object
{
    void func();
};




class signal_templ_container
{
public:

    virtual ~signal_templ_container() {

    }

    virtual bool objected() {
        return false;
    }
};



template <typename Object, typename FuncDecl>
class signal_objcall_container : public signal_templ_container
{
public:

    signal_objcall_container() {
        object = 0;
    }

    template <typename T>
    signal_objcall_container(Object obj, T func) {
        object = obj;
        obj_function = (decltype(obj_function))func;
    }

    template <typename... Args>
    void trigger(Args... args) {

        if(object) {
            auto call = (void (simple_object::*)(Args...))obj_function;
            simple_object *o = (simple_object *)object;
            (o->*call)(args...);
        }
    }

    bool operator==(const signal_objcall_container<simple_object, FuncDecl> &c) {
        if(c.object == object && c.obj_function == obj_function)
                return true;

        return false;
    }

    bool objected() {
        return true;
    }

private:
    Object object;
    void (simple_object::*obj_function)();
};



template <typename FuncDecl>
class signal_call_container : public signal_templ_container
{
public:
    signal_call_container() {

    }

    template<typename T>
    signal_call_container(T func) {
        function = func;
    }

    template <typename... Args>
    void trigger(Args... args) {
        function(args...);
    }

    bool operator==(const signal_call_container<FuncDecl> &c) {
        if(c.function == function)
            return true;

        return false;
    }

    bool objected() {
        return false;
    }

private:
    std::function<FuncDecl> function;
};



template <typename Object, typename FuncDecl>
class signal_container
{
public:

    signal_container() : container(0) {
    }

    ~signal_container() {
        if(container) {
            delete container;
        }
    }

    template<typename T>
    signal_container(Object obj, T func) {
        auto p = new signal_objcall_container<Object, FuncDecl>(obj, func);
        container = (signal_templ_container*) (p);
    }


    template<typename T>
    signal_container(T func) {
        auto p = new signal_call_container<FuncDecl>(func);
        container = (signal_templ_container*) (p);
    }

    template <typename... Args>
    void trigger(Args... args) {
        if(container) {
            if(container->objected()) {
                auto p = (signal_objcall_container<simple_object*, FuncDecl>*)container;
                p->trigger(args...);
            } else {
                auto p = (signal_call_container<FuncDecl>*)container;
                p->trigger(args...);
            }
        }
    }

    /*bool operator==(const signal_container<simple_object, FuncDecl> &c) {

        return false;
    }*/

private:
    signal_templ_container *container;
};



template <typename FuncDecl>
class signal
{
public:

    signal() :
        _slot(0) {

    }

    ~signal() {
        if(_slot)
            delete _slot;
    }

    template <typename t>
    void connect( t func )
    {
        if(_slot)
            delete _slot;

        _slot = new signal_container<simple_object*, FuncDecl>(func);
    }

    template <class ObjType, class Obj, typename Func>
    void connect(Obj obj, Func func )
    {
        if(_slot)
            delete _slot;

        _slot = (signal_container<simple_object*, FuncDecl> *)new signal_container<ObjType, FuncDecl>(obj, func);
    }

    void disconnect()
    {
        if(_slot)
            delete _slot;

        _slot = 0;
    }

    template <typename... Args>
    void trigger(Args... args) {
        if(_slot)
            _slot->trigger(args...);
    }

    signal_container<simple_object*, FuncDecl> *_slot;
};



template <typename FuncDecl>
class multi_signal
{
public:


    typedef signal_container<simple_object*, FuncDecl> template_container;
    typename std::list<signal_container<simple_object*, FuncDecl>*>::iterator iterator;

    typedef decltype(iterator) slot;

    ~multi_signal() {
        clear();
    }

    void clear()
    {
        for(template_container * _slot : _slots )
            delete _slot;

        _slots.clear();
    }



    template <typename t>
    auto connect( t func ) -> decltype(iterator)
    {
        _slots.push_back( new template_container(func) );
        return (--_slots.end());
    }

    template <typename Obj, typename Func>
    auto connect(Obj obj, Func func ) -> decltype(iterator)
    {
        _slots.push_back((template_container *)new signal_container<Obj, FuncDecl>(obj, func));
        return (--_slots.end());
    }


    template <class Iterator>
    void disconnect(Iterator it) {
        signal_container<simple_object*, FuncDecl> *obj = (*it);
        _slots.erase(it);
        delete obj;
    }

    template <typename... Args>
    void trigger(Args... args) {

        for(template_container * slot : _slots )
            slot->trigger(args...);
    }

    std::list<signal_container<simple_object*, FuncDecl> *> _slots;
};


} // signal_slot


#endif // SIGNAL_H
